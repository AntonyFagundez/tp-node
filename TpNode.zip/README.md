# Trabajo Practico Node-Express

### Tecnologias Usadas

* NodeJS
* Express
* Sesiones
* MongoDB
* Handlebars

----------

#### Para poder Utilizarlo:

> Desde la carpeta del proyecto

```
npm install
```

```
npm start
```

Autores:

> * Antony Fagundez
> * Lucas Laino
> * Sebastian Silva
> * Macarena Calderon
> * Maria Eizayaga
> * Romina Cordoba

